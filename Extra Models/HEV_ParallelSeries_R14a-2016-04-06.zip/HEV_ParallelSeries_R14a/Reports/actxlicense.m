function lic = actxlicense(progid)
% Copyright 2011 The MathWorks, Inc.
if strcmpi(progid, 'air.airctrl.1')
lic = 'Copyright (c) 1996 ';
return;
end
